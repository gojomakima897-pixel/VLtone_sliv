# Design a VLTONE theme

## Edit your first control

1. Open **Appearance → Theme editor**. Use **File → New from example** to make a personal draft. Workbench has a three-row transport and a custom window. Christmas Eve demonstrates layered ornaments, artwork and animation.
2. Find `transport.play` in the element tree or pick the Play button in the application. The close-up in the right inspector shows the control. The main canvas shows its place in the panel. Choose a state to see its focus, pressed or hover styling.
3. Open **Appearance** on the right. Edit a colour or open **Graphic layers** to change the artwork. Use the scope selector to edit this control or all controls of the same type. A field tooltip identifies its inherited value. Use the reset button beside that field to remove its override. Drag a number vertically to adjust it, hold Shift for precision, or double-click to type. One theme Undo reverses a property drag.
4. Use **Placement** for exact coordinates and sizes. Enable the grid and snapping, then drag a control. Hold Shift during a drag to ignore the grid. Arrow keys move the selection, Shift increases the keyboard step, and Alt resizes it. Increase the panel height to make space for another row. Open **Arrange** to align or group a selection.
5. Test the layout using the width, scale, language and state controls. **Preview in application** lets you operate the real controls. **Revert** restores the previous application appearance. **Apply** lets you commit appearance and layout independently. Save the draft or export a portable `.vlttheme` from **File**.

## Build a panel or a script

In **Panels and widgets**, create a `user.` panel, choose a window, dock or inline host and add controls. Bind your button to an existing command from the command list. A slider can control a parameter such as `selectedTrack.volume`. Two settings fields with the same `setting` share a value within that panel. A separate Lua Script SDK command can edit clips, respond to a button or open a script window. Install that script and select its command in the panel. Distribute required scripts alongside the theme.

Under **Code**, edit JSON directly or use a Lua generator. For example:

~~~lua
return {
  schemaVersion = 2, name = "Winter keys",
  elements = {
    ["transport.play"] = {material = "flat", background = "#315C4B", radius = 9}
  }
}
~~~

Validate the source and inspect the result on the canvas. A generator returns a theme table. Use `array { ... }` for lists, especially empty ones. Mouse edits are stored above the generated values. Invalid source keeps the last working preview. Resolve external changes or save a copy before replacing source files. The **Guide** includes the full format, runnable JSON and Lua examples, the Script SDK and its interactive controls example.

## Work with a design assistant

Choose **Create theme with AI…** to open the chat next to the preview. **Models…** opens the application's model settings. Select a configured model, then choose **Explain only** or **Edit the draft**. Try “Put Play, Stop and Record in two rows and keep their size.” Review the result and use theme Undo to reverse the change.

For an external assistant, open **MCP…**, enable the local server and copy its connection configuration to the MCP client. Keep the configuration's token private. Read `vltone://theme/ai` and `vltone://theme/contract`. The tools `get_theme_draft` and `edit_theme_draft` share this editor's current draft and undo history. Read the current revision again after a manual edit.

Use **F1** inside the editor to open help. To recover the factory interface, start VLTONE with `--safe-theme`.

### Connect your own model

Open **Models…** in the chat. Choose an account model or add a connection. For a custom connection, enter its display name, an OpenAI-compatible or Anthropic-compatible protocol, the provider's exact model ID and the server URL. Supply an API key if your server requires one. VLTONE stores custom keys in the operating system's credential vault. Save the connection and select it in the chat. Enter sends, Shift+Enter inserts a line and **Stop** interrupts the response.

For a first external MCP request, call `get_theme_draft` with `{"elementQuery":"transport.play"}`. The response describes the button's parts, properties, states and actions. Use `commandQuery` to find the command of an installed script. The editor guide includes a matching command manifest and its `main.lua`.
