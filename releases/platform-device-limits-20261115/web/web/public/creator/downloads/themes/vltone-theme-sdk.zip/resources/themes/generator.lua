-- Lua returns the same document that the visual editor edits.
-- No host commands, files, network, imports or per-frame callbacks are available.
local accent = "#82c9b0"
return {
  schemaVersion = 2,
  name = "Generated studio",
  defaults = { material = "flat", radius = 2, borderWidth = 0 },
  components = {
    button = {
      background = "#2f363a", foreground = "#ecf1f2",
      states = { checked = { background = accent, foreground = "#162c24" } }
    }
  },
  elements = {}, overrides = {}, assets = {},
  layouts = {
    ["transport.controls"] = {
      mode = "row", padding = 4, gap = 3,
      items = {
        { id = "transport.play", width = 40 },
        { id = "transport.stop", width = 32 },
        { id = "transport.record", width = 32 },
        { id = "transport.loop", width = 32 },
        { id = "transport.metronome", width = 32 },
        { id = "transport.start", width = 24 },
        { id = "transport.rewind", width = 24 },
        { id = "transport.forward", width = 24 }
      }
    }
  }
}
