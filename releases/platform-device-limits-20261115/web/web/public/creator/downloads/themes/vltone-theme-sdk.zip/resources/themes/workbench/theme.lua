-- Every position is in logical pixels. The window and the header use the same widgets in JSON.
local header = array {
  { id = "transport", x = 154, y = 8, width = "66%", height = 108 },
  { id = "transport.controls", visible = false },
  { id = "workspace.tools", anchor = "top-right", offsetX = -200, y = 10, width = 158, height = 42 },
  { id = "workspace.windows", anchor = "top-right", offsetX = -10, y = 10, width = 170, height = 42 },
  { id = "user.trackSwitch", anchor = "bottom-right", offsetX = -12, offsetY = -12, width = 150, height = 36 }
}
local keys = {"start", "rewind", "forward", "stop", "play", "record", "metronome", "loop"}
for i, name in ipairs(keys) do
  header[#header + 1] = { id = "transport." .. name, x = 14 + ((i - 1) % 3) * 43,
                         y = 9 + math.floor((i - 1) / 3) * 38, width = 39, height = 33 }
end
return {
  schemaVersion = 2, name = "Пульт в три ряда",
  defaults = { material = "flat", radius = 3, borderWidth = 1 },
  palette = { dark = true, background = "#1c2227", surface = "#242d33", surfaceElevated = "#334048",
              accent = "#8fcebd", textPrimary = "#e9f1ee", textSecondary = "#b4c4c3" },
  components = { button = {background = "#35424a", foreground = "#edf4ef", border = "#47575d",
                           states = { checked = {background = "#36675c"}, hover = {background = "#46565d"} } } },
  layouts = {
    ["workspace.header"] = { mode = "free", scope = "descendants", canvasHeight = 132, items = header },
    transport = { mode = "free", scope = "descendants", items = array {
      { id = "transport.display", x = 4, y = 3, width = 387, height = 44 },
      { id = "workspace.editTools", x = 4, y = 57, width = 302, height = 43 }
    } }
  },
  panels = {
    ["user.trackSwitch"] = {
      title = "Выбранная дорожка", host = "workspace.header", width = 150, height = 36,
      controls = array { {id = "user.trackSwitch.solo", type = "toggle", label = "Solo дорожки",
                           parameter = "selectedTrack.solo", x = 2, y = 2, width = 146, height = 32} }
    },
    ["user.playDeck"] = {
      title = "Мой пульт", host = "window", width = 366, height = 156,
      controls = array {
        {id = "user.playDeck.play", type = "button", label = "Старт / пауза", command = "transport.playPause",
         x = 10, y = 10, width = 162, height = 36},
        {id = "user.playDeck.stop", type = "button", label = "Стоп", command = "transport.stop",
         x = 182, y = 10, width = 168, height = 36},
        {id = "user.playDeck.tempo", type = "number", label = "BPM", parameter = "transport.tempo",
         min = 20, max = 400, step = 0.1, x = 10, y = 57, width = 162, height = 34},
        {id = "user.playDeck.mute", type = "toggle", label = "Mute дорожки", parameter = "selectedTrack.mute",
         x = 182, y = 57, width = 168, height = 34},
        {id = "user.playDeck.note", type = "text", label = "Моя заметка", setting = "note",
         x = 10, y = 103, width = 340, height = 34}
      }
    }
  }
}
