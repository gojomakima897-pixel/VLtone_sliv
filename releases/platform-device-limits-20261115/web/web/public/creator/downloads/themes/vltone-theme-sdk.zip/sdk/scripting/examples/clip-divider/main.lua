-- The control stays attached to the clip selected when this window opened.
local context = vlt.context.get()
local target = context.target or {}
local trackId, clipId = target.track, target.clip
if not clipId or clipId == "" then
    local selected = (context.selection or {}).clips or {}
    if #selected == 1 then
        local entry = selected[1]
        clipId = type(entry) == "table" and entry.id or entry
        trackId = type(entry) == "table" and entry.track or nil
    end
end
if not clipId or clipId == "" then return {message="Select one clip to divide."} end

local function readClip()
    local project = vlt.project.get{track=trackId, clip=clipId, includeEvents=false}
    for _, track in ipairs(project.tracks) do
        for _, clip in ipairs(track.clips or {}) do
            if clip.id == clipId then return project, track.id, clip end
        end
    end
    error("This clip is no longer available.", 0)
end
local project, _, clip = readClip()
local function describe(count)
    local beats = clip.length / count
    vlt.ui.set{id="summary", text=string.format("%d parts  ·  %.3g beats each", count, beats)}
    vlt.ui.set{id="split", enabled=beats > (project.minimumClipLength or 0)}
end
local function commit()
    local ok, result = pcall(function()
        local fresh, track, current = readClip()
        local count = math.floor(vlt.ui.get{id="parts"}.value)
        if current.length / count <= (fresh.minimumClipLength or 0) then
            error("Choose fewer parts for this clip.", 0)
        end
        local cuts = {}
        -- Each split keeps the original ID on the left.
        for i = count-1, 1, -1 do
            cuts[#cuts+1] = {op="clip.split", track=track, clip=clipId,
                             at=current.start + current.length * i / count}
        end
        vlt.project.apply{revision=fresh.revision, label="Clip Divider", operations=cuts}
        return string.format("Split into %d parts.", count)
    end)
    vlt.ui.set{id="summary", text=tostring(result)}
    if ok then
        vlt.ui.set{id="split", enabled=false}
        vlt.ui.set{id="parts", enabled=false}
    end
end

vlt.ui.window{id="divider", title="Clip Divider", width=330, height=210, children={
    {type="label", text=clip.name or "Selected clip"},
    {type="number", id="parts", label="Parts", min=2, max=32, decimals=0, step=1, value=4,
     onChange=function(event) describe(event.value) end},
    {type="label", id="summary", text=""},
    {type="button", id="split", text="Split clip", onClick=commit}
}}
describe(4)
