module.exports=[34267,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_models_page_actions_1dl1w7i.js.map