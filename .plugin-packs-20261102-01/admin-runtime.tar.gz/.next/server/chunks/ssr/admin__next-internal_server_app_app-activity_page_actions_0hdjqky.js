module.exports=[69998,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_app-activity_page_actions_0hdjqky.js.map