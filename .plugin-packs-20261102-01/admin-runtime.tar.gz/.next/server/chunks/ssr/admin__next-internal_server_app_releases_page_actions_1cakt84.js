module.exports=[94410,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_releases_page_actions_1cakt84.js.map