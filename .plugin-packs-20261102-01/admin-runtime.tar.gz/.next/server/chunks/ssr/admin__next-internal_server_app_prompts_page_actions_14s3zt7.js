module.exports=[49218,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_prompts_page_actions_14s3zt7.js.map