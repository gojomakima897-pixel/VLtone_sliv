module.exports=[14349,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_bugs_page_actions_088mn-x.js.map