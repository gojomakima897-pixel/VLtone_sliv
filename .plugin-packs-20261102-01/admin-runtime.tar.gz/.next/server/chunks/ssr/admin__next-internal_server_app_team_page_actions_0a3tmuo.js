module.exports=[77576,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_team_page_actions_0a3tmuo.js.map