module.exports=[33941,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_plugin-packs_page_actions_0th9c3p.js.map