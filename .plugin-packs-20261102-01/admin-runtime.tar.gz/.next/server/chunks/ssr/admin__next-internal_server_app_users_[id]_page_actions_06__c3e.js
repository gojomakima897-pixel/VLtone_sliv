module.exports=[16961,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_users_%5Bid%5D_page_actions_06__c3e.js.map