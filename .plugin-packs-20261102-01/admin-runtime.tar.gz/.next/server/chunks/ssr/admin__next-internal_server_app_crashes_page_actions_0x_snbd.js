module.exports=[1061,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_crashes_page_actions_0x_snbd.js.map