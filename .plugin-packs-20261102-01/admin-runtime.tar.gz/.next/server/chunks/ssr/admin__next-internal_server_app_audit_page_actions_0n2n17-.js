module.exports=[15958,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_audit_page_actions_0n2n17-.js.map