module.exports=[21986,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_browser-backgrounds_page_actions_054huou.js.map