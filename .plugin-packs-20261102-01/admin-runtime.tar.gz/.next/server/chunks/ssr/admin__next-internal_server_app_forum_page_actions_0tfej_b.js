module.exports=[27483,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_forum_page_actions_0tfej_b.js.map