module.exports=[85587,(a,b,c)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_analytics_page_actions_02b3j0u.js.map