module.exports=[913,(e,o,d)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_icon_png_route_actions_144_dt7.js.map