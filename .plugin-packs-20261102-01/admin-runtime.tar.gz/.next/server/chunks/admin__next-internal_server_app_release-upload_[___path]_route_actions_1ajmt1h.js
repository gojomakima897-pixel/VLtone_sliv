module.exports=[11772,(e,o,d)=>{}];

//# sourceMappingURL=admin__next-internal_server_app_release-upload_%5B___path%5D_route_actions_1ajmt1h.js.map