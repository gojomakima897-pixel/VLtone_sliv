var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/release-upload/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__005978y._.js")
R.c("server/chunks/[root-of-the-server]__0234fvx._.js")
R.c("server/chunks/admin__next-internal_server_app_release-upload_[___path]_route_actions_1ajmt1h.js")
R.m(60350)
module.exports=R.m(60350).exports
