var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]__1kyc1js._.js")
R.c("server/chunks/_01brhzo._.js")
R.c("server/chunks/[root-of-the-server]__0234fvx._.js")
R.c("server/chunks/admin__next-internal_server_app_icon_png_route_actions_144_dt7.js")
R.m(96040)
module.exports=R.m(96040).exports
