:HL["/_next/static/chunks/017b4iz63m3eq.css","style"]
:HL["/_next/static/media/Inter_Bold-s.p.1vux9k4ut5xg-.ttf","font",{"crossOrigin":"","type":"font/ttf"}]
:HL["/_next/static/media/Inter_Medium-s.p.05nojmsrnwpdx.ttf","font",{"crossOrigin":"","type":"font/ttf"}]
:HL["/_next/static/media/Inter_Regular-s.p.06fx2jlp7ambl.ttf","font",{"crossOrigin":"","type":"font/ttf"}]
:HL["/_next/static/media/Inter_SemiBold-s.p.1szzmfhh1h9ui.ttf","font",{"crossOrigin":"","type":"font/ttf"}]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"app-activity","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"ImYRUJvv5tccV-t8P2PBH"}
