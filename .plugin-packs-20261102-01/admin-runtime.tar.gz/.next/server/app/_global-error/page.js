var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/[root-of-the-server]__10l_tfu._.js")
R.c("server/chunks/ssr/1z-4_next_dist_0_na1mh._.js")
R.c("server/chunks/ssr/[root-of-the-server]__18v2pdh._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1vodqaq._.js")
R.c("server/chunks/ssr/1z-4_next_dist_client_components_builtin_global-error_0q8erds.js")
R.c("server/chunks/ssr/admin__next-internal_server_app__global-error_page_actions_198h-3f.js")
R.m(70245)
module.exports=R.m(70245).exports
