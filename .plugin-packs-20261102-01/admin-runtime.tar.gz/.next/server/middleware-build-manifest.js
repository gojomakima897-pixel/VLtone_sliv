globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ImYRUJvv5tccV-t8P2PBH/_buildManifest.js",
    "static/ImYRUJvv5tccV-t8P2PBH/_ssgManifest.js",
    "static/ImYRUJvv5tccV-t8P2PBH/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1alxkw81-gjpw.js",
    "static/chunks/2qmky9z9uejxo.js",
    "static/chunks/192qfa5y3oz5f.js",
    "static/chunks/0owyihitymdg2.js",
    "static/chunks/turbopack-0nr0bwf0wjw30.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
